To do
*****

Generalise to Vector
====================

a lot of functions

Layout
======

  - `figure_size` should be deprecated, instead use figure with keywords
  - errorbars
